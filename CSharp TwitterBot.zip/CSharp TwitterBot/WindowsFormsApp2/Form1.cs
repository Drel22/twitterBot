﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tweetinvi;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string ckey = ConfigurationManager.AppSettings["cKey"];
            string cSecret = ConfigurationManager.AppSettings["cSecret"];
            string aKey = ConfigurationManager.AppSettings["aKey"];
            string aSecret = ConfigurationManager.AppSettings["aSecret"];

            Auth.SetUserCredentials(ckey,cSecret,aKey,aSecret);
            string targetAccount = textBox2.Text;
            textBox2.Text = "";
            System.Data.DataTable table = new System.Data.DataTable();
            table.Columns.Add("Creator of Tweet", typeof(string));
            table.Columns.Add("Date", typeof(string));
            table.Columns.Add("Text", typeof(string));
            var targetUser = User.GetUserFromScreenName(targetAccount);
            if (targetUser != null)
            {
                var userTweets = Timeline.GetUserTimeline(targetUser.Id, 30).ToArray();
                var userTweetList = new List<Tweetinvi.Models.ITweet>(userTweets);
                foreach (var tweet in userTweetList)
                {
                    table.Rows.Add(tweet.CreatedBy, tweet.CreatedAt.ToString(), tweet.FullText);// Add info to work
                }
            }
            dataGridView1.DataSource = table;
            Microsoft.Office.Interop.Excel.Application xlApp = new Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            xlWorkBook = xlApp.Workbooks.Add(Type.Missing);

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.ActiveSheet;
            xlWorkSheet.Name = "FBIReport";

            xlWorkSheet.Range[xlWorkSheet.Cells[1, 1], xlWorkSheet.Cells[1, 8]].Merge();
            xlWorkSheet.Cells[1, 1] = "FBIReport of " + targetAccount;
            xlWorkSheet.Cells[1, 1].Font.Size = 15;

            ///Add info from Data Table to the Excel Sheet
            xlWorkSheet.Columns[1].ColumnWidth = 15;
            xlWorkSheet.Columns[2].ColumnWidth = 15;
            xlWorkSheet.Columns[3].ColumnWidth = 15;
            xlWorkSheet.Cells[2, 1] = table.Columns[0].ColumnName;
            xlWorkSheet.Cells[2, 2] = table.Columns[1].ColumnName;
            xlWorkSheet.Cells[2, 3] = table.Columns[2].ColumnName;

            //Iterate through each row in table in add to the row
            int rowcount = 3;
            foreach (System.Data.DataRow datarow in table.Rows)
            {
                xlWorkSheet.Cells[rowcount, 1] = datarow[0];
                xlWorkSheet.Cells[rowcount, 2] = datarow[1];
                xlWorkSheet.Cells[rowcount, 3] = datarow[2];
                rowcount += 1;
            }

            xlWorkBook.SaveAs(@"YourDirectory" + targetAccount + "_Report.xls", Excel.XlFileFormat.xlWorkbookNormal);
            xlWorkBook.Close();
            xlApp.Quit();

            label2.Visible = false;
            button1.Visible = false;
            dataGridView1.Visible = true;
            textBox1.Visible = true;
            label1.Visible = true;
            button3.Visible = true;
           //button2.Visible = true;

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = string.Format("Text LIKE '%{0}%'", textBox1.Text);
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string tweet = dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            string arg = tweet.Replace(' ', '|');
            serialPort1.Open();
            string message = "/printLCDAndLightRGB/run " + "1" + arg;
            Console.WriteLine(message);
            serialPort1.WriteLine(message); 
            serialPort1.Close();
            textBox1.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            string arg = button3.Text.Replace(' ', '|');
            string message = "/printLCDAndLightRGB/run " + "0" + arg;
            serialPort1.WriteLine(message);
            serialPort1.Close();
        }
    }
}
